﻿namespace Pharmacy_project.AdministratorUC
{
    partial class UC_AddUser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_AddUser));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtEmail = new Label();
            label7 = new Label();
            label8 = new Label();
            txtUserRole = new Guna.UI2.WinForms.Guna2ComboBox();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            txtMobileNo = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            txtUserName = new Guna.UI2.WinForms.Guna2TextBox();
            txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            txtDob = new Guna.UI2.WinForms.Guna2DateTimePicker();
            panel1 = new Panel();
            btnSignUp = new Guna.UI2.WinForms.Guna2Button();
            btnReset = new Guna.UI2.WinForms.Guna2Button();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 22F, FontStyle.Bold);
            label1.Location = new Point(36, 32);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(214, 51);
            label1.TabIndex = 0;
            label1.Text = "Add User";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(183, 286);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(121, 29);
            label2.TabIndex = 1;
            label2.Text = "User Role";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 12F);
            label3.Location = new Point(183, 414);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(78, 29);
            label3.TabIndex = 2;
            label3.Text = "Name";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 12F);
            label4.Location = new Point(183, 559);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(218, 29);
            label4.TabIndex = 3;
            label4.Text = "DOB (Date of Birth)";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 12F);
            label5.Location = new Point(183, 698);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(131, 29);
            label5.TabIndex = 4;
            label5.Text = "Mobile No.";
            // 
            // txtEmail
            // 
            txtEmail.AutoSize = true;
            txtEmail.Font = new Font("Microsoft Sans Serif", 12F);
            txtEmail.Location = new Point(756, 286);
            txtEmail.Margin = new Padding(4, 0, 4, 0);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(74, 29);
            txtEmail.TabIndex = 5;
            txtEmail.Text = "Email";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 12F);
            label7.Location = new Point(756, 414);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(135, 29);
            label7.TabIndex = 6;
            label7.Text = "User Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 12F);
            label8.Location = new Point(756, 562);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(120, 29);
            label8.TabIndex = 7;
            label8.Text = "Password";
            // 
            // txtUserRole
            // 
            txtUserRole.BackColor = Color.Transparent;
            txtUserRole.CustomizableEdges = customizableEdges19;
            txtUserRole.DrawMode = DrawMode.OwnerDrawFixed;
            txtUserRole.DropDownStyle = ComboBoxStyle.DropDownList;
            txtUserRole.FocusedColor = Color.FromArgb(94, 148, 255);
            txtUserRole.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUserRole.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUserRole.ForeColor = Color.Black;
            txtUserRole.ItemHeight = 30;
            txtUserRole.Items.AddRange(new object[] { "Administrator", "Pharmaicists" });
            txtUserRole.Location = new Point(183, 318);
            txtUserRole.Margin = new Padding(4, 3, 4, 3);
            txtUserRole.Name = "txtUserRole";
            txtUserRole.ShadowDecoration.CustomizableEdges = customizableEdges20;
            txtUserRole.Size = new Size(340, 36);
            txtUserRole.TabIndex = 8;
            txtUserRole.SelectedIndexChanged += guna2ComboBox1_SelectedIndexChanged;
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges21;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtName.ForeColor = Color.Black;
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(183, 449);
            txtName.Margin = new Padding(5, 6, 5, 6);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges22;
            txtName.Size = new Size(340, 36);
            txtName.TabIndex = 9;
            txtName.TextChanged += guna2TextBox1_TextChanged;
            // 
            // txtMobileNo
            // 
            txtMobileNo.CustomizableEdges = customizableEdges23;
            txtMobileNo.DefaultText = "";
            txtMobileNo.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMobileNo.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMobileNo.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMobileNo.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMobileNo.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobileNo.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMobileNo.ForeColor = Color.Black;
            txtMobileNo.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobileNo.Location = new Point(183, 733);
            txtMobileNo.Margin = new Padding(5, 6, 5, 6);
            txtMobileNo.Name = "txtMobileNo";
            txtMobileNo.PasswordChar = '\0';
            txtMobileNo.PlaceholderText = "";
            txtMobileNo.SelectedText = "";
            txtMobileNo.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtMobileNo.Size = new Size(340, 36);
            txtMobileNo.TabIndex = 10;
            txtMobileNo.TextChanged += guna2TextBox2_TextChanged;
            // 
            // guna2TextBox3
            // 
            guna2TextBox3.CustomizableEdges = customizableEdges25;
            guna2TextBox3.DefaultText = "";
            guna2TextBox3.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox3.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox3.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox3.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox3.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2TextBox3.ForeColor = Color.Black;
            guna2TextBox3.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox3.Location = new Point(756, 318);
            guna2TextBox3.Margin = new Padding(5, 6, 5, 6);
            guna2TextBox3.Name = "guna2TextBox3";
            guna2TextBox3.PasswordChar = '\0';
            guna2TextBox3.PlaceholderText = "";
            guna2TextBox3.SelectedText = "";
            guna2TextBox3.ShadowDecoration.CustomizableEdges = customizableEdges26;
            guna2TextBox3.Size = new Size(340, 36);
            guna2TextBox3.TabIndex = 11;
            // 
            // txtUserName
            // 
            txtUserName.CustomizableEdges = customizableEdges27;
            txtUserName.DefaultText = "";
            txtUserName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtUserName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtUserName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtUserName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtUserName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUserName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUserName.ForeColor = Color.Black;
            txtUserName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUserName.Location = new Point(756, 449);
            txtUserName.Margin = new Padding(5, 6, 5, 6);
            txtUserName.Name = "txtUserName";
            txtUserName.PasswordChar = '\0';
            txtUserName.PlaceholderText = "";
            txtUserName.SelectedText = "";
            txtUserName.ShadowDecoration.CustomizableEdges = customizableEdges28;
            txtUserName.Size = new Size(340, 36);
            txtUserName.TabIndex = 12;
            txtUserName.TextChanged += guna2TextBox4_TextChanged;
            // 
            // txtPassword
            // 
            txtPassword.CustomizableEdges = customizableEdges29;
            txtPassword.DefaultText = "";
            txtPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassword.ForeColor = Color.Black;
            txtPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Location = new Point(756, 597);
            txtPassword.Margin = new Padding(5, 6, 5, 6);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '\0';
            txtPassword.PlaceholderText = "";
            txtPassword.SelectedText = "";
            txtPassword.ShadowDecoration.CustomizableEdges = customizableEdges30;
            txtPassword.Size = new Size(340, 36);
            txtPassword.TabIndex = 13;
            // 
            // txtDob
            // 
            txtDob.Checked = true;
            txtDob.CustomizableEdges = customizableEdges31;
            txtDob.Font = new Font("Segoe UI", 9F);
            txtDob.Format = DateTimePickerFormat.Long;
            txtDob.Location = new Point(183, 597);
            txtDob.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            txtDob.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            txtDob.Name = "txtDob";
            txtDob.ShadowDecoration.CustomizableEdges = customizableEdges32;
            txtDob.Size = new Size(340, 36);
            txtDob.TabIndex = 14;
            txtDob.Value = new DateTime(2024, 2, 19, 12, 47, 1, 999);
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 118, 225);
            panel1.Location = new Point(619, 249);
            panel1.Name = "panel1";
            panel1.Size = new Size(6, 566);
            panel1.TabIndex = 15;
            // 
            // btnSignUp
            // 
            btnSignUp.BorderRadius = 30;
            btnSignUp.BorderThickness = 1;
            btnSignUp.CustomizableEdges = customizableEdges33;
            btnSignUp.DisabledState.BorderColor = Color.DarkGray;
            btnSignUp.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSignUp.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSignUp.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSignUp.FillColor = Color.FromArgb(0, 118, 225);
            btnSignUp.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSignUp.ForeColor = Color.White;
            btnSignUp.HoverState.FillColor = Color.White;
            btnSignUp.HoverState.ForeColor = Color.FromArgb(0, 118, 225);
            btnSignUp.Image = (Image)resources.GetObject("btnSignUp.Image");
            btnSignUp.ImageSize = new Size(30, 30);
            btnSignUp.Location = new Point(695, 687);
            btnSignUp.Name = "btnSignUp";
            btnSignUp.ShadowDecoration.CustomizableEdges = customizableEdges34;
            btnSignUp.Size = new Size(195, 54);
            btnSignUp.TabIndex = 16;
            btnSignUp.Text = "Sign Up";
            // 
            // btnReset
            // 
            btnReset.BorderRadius = 30;
            btnReset.BorderThickness = 1;
            btnReset.CustomizableEdges = customizableEdges35;
            btnReset.DisabledState.BorderColor = Color.DarkGray;
            btnReset.DisabledState.CustomBorderColor = Color.DarkGray;
            btnReset.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnReset.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnReset.FillColor = Color.FromArgb(0, 118, 225);
            btnReset.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReset.ForeColor = Color.White;
            btnReset.HoverState.FillColor = Color.White;
            btnReset.HoverState.ForeColor = Color.FromArgb(0, 118, 225);
            btnReset.Image = (Image)resources.GetObject("btnReset.Image");
            btnReset.ImageSize = new Size(30, 30);
            btnReset.Location = new Point(950, 687);
            btnReset.Name = "btnReset";
            btnReset.ShadowDecoration.CustomizableEdges = customizableEdges36;
            btnReset.Size = new Size(195, 54);
            btnReset.TabIndex = 17;
            btnReset.Text = "Reset";
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.TargetControl = this;
            // 
            // UC_AddUser
            // 
            AutoScaleDimensions = new SizeF(14F, 29F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(btnReset);
            Controls.Add(btnSignUp);
            Controls.Add(panel1);
            Controls.Add(txtDob);
            Controls.Add(txtPassword);
            Controls.Add(txtUserName);
            Controls.Add(guna2TextBox3);
            Controls.Add(txtMobileNo);
            Controls.Add(txtName);
            Controls.Add(txtUserRole);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(txtEmail);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Microsoft Sans Serif", 12F);
            Margin = new Padding(4, 3, 4, 3);
            Name = "UC_AddUser";
            Size = new Size(1793, 1072);
            Load += UC_AddUser_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label txtEmail;
        private Label label7;
        private Label label8;
        private Guna.UI2.WinForms.Guna2ComboBox txtUserRole;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2TextBox txtMobileNo;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private Guna.UI2.WinForms.Guna2TextBox txtUserName;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private Guna.UI2.WinForms.Guna2DateTimePicker txtDob;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btnSignUp;
        private Guna.UI2.WinForms.Guna2Button btnReset;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
