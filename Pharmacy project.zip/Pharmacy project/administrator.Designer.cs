﻿namespace Pharmacy_project
{
    partial class administrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(administrator));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            label2 = new Label();
            btnLogout = new Guna.UI2.WinForms.Guna2Button();
            guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            btnAddUser = new Guna.UI2.WinForms.Guna2Button();
            btnDashboard = new Guna.UI2.WinForms.Guna2Button();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            uC_AddUser1 = new AdministratorUC.UC_AddUser();
            uC_Dashborad1 = new AdministratorUC.UC_Dashborad();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.MistyRose;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(btnLogout);
            panel1.Controls.Add(guna2Button4);
            panel1.Controls.Add(guna2Button3);
            panel1.Controls.Add(btnAddUser);
            panel1.Controls.Add(btnDashboard);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(449, 924);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Calibri", 18F);
            label2.ForeColor = Color.FromArgb(64, 64, 64);
            label2.Location = new Point(96, 819);
            label2.Name = "label2";
            label2.Size = new Size(221, 44);
            label2.TabIndex = 0;
            label2.Text = "hashimshahid";
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.Moccasin;
            btnLogout.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnLogout.CheckedState.FillColor = Color.FromArgb(255, 193, 193);
            btnLogout.CheckedState.ForeColor = Color.Black;
            btnLogout.CustomizableEdges = customizableEdges1;
            btnLogout.DisabledState.BorderColor = Color.DarkGray;
            btnLogout.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLogout.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLogout.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLogout.FillColor = Color.MistyRose;
            btnLogout.Font = new Font("Century", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLogout.ForeColor = Color.Black;
            btnLogout.Image = (Image)resources.GetObject("btnLogout.Image");
            btnLogout.ImageSize = new Size(30, 30);
            btnLogout.Location = new Point(45, 688);
            btnLogout.Name = "btnLogout";
            btnLogout.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnLogout.Size = new Size(357, 59);
            btnLogout.TabIndex = 4;
            btnLogout.Text = "Logout";
            btnLogout.Click += btnLogout_Click;
            // 
            // guna2Button4
            // 
            guna2Button4.BackColor = Color.Moccasin;
            guna2Button4.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button4.CheckedState.FillColor = Color.FromArgb(255, 193, 193);
            guna2Button4.CheckedState.ForeColor = Color.Black;
            guna2Button4.CustomizableEdges = customizableEdges3;
            guna2Button4.DisabledState.BorderColor = Color.DarkGray;
            guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button4.FillColor = Color.MistyRose;
            guna2Button4.Font = new Font("Century", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2Button4.ForeColor = Color.Black;
            guna2Button4.Image = (Image)resources.GetObject("guna2Button4.Image");
            guna2Button4.ImageSize = new Size(30, 30);
            guna2Button4.Location = new Point(48, 514);
            guna2Button4.Name = "guna2Button4";
            guna2Button4.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Button4.Size = new Size(357, 59);
            guna2Button4.TabIndex = 3;
            guna2Button4.Text = "View User";
            // 
            // guna2Button3
            // 
            guna2Button3.BackColor = Color.Moccasin;
            guna2Button3.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button3.CheckedState.FillColor = Color.FromArgb(255, 193, 193);
            guna2Button3.CheckedState.ForeColor = Color.Black;
            guna2Button3.CustomizableEdges = customizableEdges5;
            guna2Button3.DisabledState.BorderColor = Color.DarkGray;
            guna2Button3.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button3.FillColor = Color.MistyRose;
            guna2Button3.Font = new Font("Century", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2Button3.ForeColor = Color.Black;
            guna2Button3.Image = (Image)resources.GetObject("guna2Button3.Image");
            guna2Button3.ImageSize = new Size(25, 25);
            guna2Button3.Location = new Point(45, 601);
            guna2Button3.Name = "guna2Button3";
            guna2Button3.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button3.Size = new Size(357, 59);
            guna2Button3.TabIndex = 2;
            guna2Button3.Text = "Profile";
            // 
            // btnAddUser
            // 
            btnAddUser.BackColor = Color.Moccasin;
            btnAddUser.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnAddUser.CheckedState.FillColor = Color.FromArgb(255, 193, 193);
            btnAddUser.CheckedState.ForeColor = Color.Black;
            btnAddUser.CustomizableEdges = customizableEdges7;
            btnAddUser.DisabledState.BorderColor = Color.DarkGray;
            btnAddUser.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddUser.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddUser.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddUser.FillColor = Color.MistyRose;
            btnAddUser.Font = new Font("Century", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAddUser.ForeColor = Color.Black;
            btnAddUser.Image = (Image)resources.GetObject("btnAddUser.Image");
            btnAddUser.ImageSize = new Size(30, 30);
            btnAddUser.Location = new Point(45, 426);
            btnAddUser.Name = "btnAddUser";
            btnAddUser.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnAddUser.Size = new Size(357, 59);
            btnAddUser.TabIndex = 1;
            btnAddUser.Text = "Add User";
            btnAddUser.Click += btnAddUser_Click;
            // 
            // btnDashboard
            // 
            btnDashboard.BackColor = Color.Moccasin;
            btnDashboard.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnDashboard.CheckedState.FillColor = Color.FromArgb(255, 193, 193);
            btnDashboard.CheckedState.ForeColor = Color.Black;
            btnDashboard.CustomizableEdges = customizableEdges9;
            btnDashboard.DisabledState.BorderColor = Color.DarkGray;
            btnDashboard.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDashboard.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDashboard.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDashboard.FillColor = Color.MistyRose;
            btnDashboard.Font = new Font("Century", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDashboard.ForeColor = Color.Black;
            btnDashboard.Image = (Image)resources.GetObject("btnDashboard.Image");
            btnDashboard.ImageSize = new Size(30, 30);
            btnDashboard.Location = new Point(45, 340);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnDashboard.Size = new Size(357, 59);
            btnDashboard.TabIndex = 0;
            btnDashboard.Text = "Dashboard";
            btnDashboard.Click += btnDashboard_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Calibri", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(75, 265);
            label1.Name = "label1";
            label1.Size = new Size(254, 49);
            label1.TabIndex = 0;
            label1.Text = "Administrator";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(55, 18);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(246, 244);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(uC_AddUser1);
            panel2.Controls.Add(uC_Dashborad1);
            panel2.Location = new Point(401, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1249, 924);
            panel2.TabIndex = 1;
            // 
            // uC_AddUser1
            // 
            uC_AddUser1.BackColor = Color.White;
            uC_AddUser1.Font = new Font("Microsoft Sans Serif", 12F);
            uC_AddUser1.Location = new Point(0, 0);
            uC_AddUser1.Margin = new Padding(4, 3, 4, 3);
            uC_AddUser1.Name = "uC_AddUser1";
            uC_AddUser1.Size = new Size(2690, 1608);
            uC_AddUser1.TabIndex = 1;
            // 
            // uC_Dashborad1
            // 
            uC_Dashborad1.BackColor = Color.White;
            uC_Dashborad1.Location = new Point(0, 0);
            uC_Dashborad1.Name = "uC_Dashborad1";
            uC_Dashborad1.Size = new Size(1874, 1386);
            uC_Dashborad1.TabIndex = 0;
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.TargetControl = panel2;
            // 
            // administrator
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1700, 920);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "administrator";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "administrator";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btnLogout;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button btnAddUser;
        private Guna.UI2.WinForms.Guna2Button btnDashboard;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
        private AdministratorUC.UC_Dashborad uC_Dashborad1;
        private AdministratorUC.UC_AddUser uC_AddUser1;
    }
}